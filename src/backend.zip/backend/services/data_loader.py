import pandas as pd
import numpy as np
from pathlib import Path

DATA_FILE = (
    Path(__file__)
    .resolve()
    .parent.parent
    / "data"
    / "Master_File.xlsx"
)

PARAMS = {
    "YIELD POINT": "Yield_Point",
    "% ELONGATION": "Elongation",
    "ULTIMATE TENSILE STRENGTH": "UTS",
    "% CARBON": "Carbon_pct",
}


def load_data():

    raw = pd.read_excel(
        DATA_FILE,
        header=1
    )

    raw = raw.dropna(how="all")

    raw.columns = (
        raw.columns
        .astype(str)
        .str.strip()
    )

    if "Inspection Lot Date" in raw.columns:

        raw["Inspection Lot Date"] = pd.to_datetime(
            raw["Inspection Lot Date"],
            errors="coerce",
            dayfirst=True
        )

    numeric_cols = [
        "Result Recorded",
        "Lower Limit",
        "Upper Limit",
        "Inspection Lot"
    ]

    for col in numeric_cols:

        if col in raw.columns:

            raw[col] = pd.to_numeric(
                raw[col],
                errors="coerce"
            )

    weight_col = None

    exact_match = [
        c
        for c in raw.columns
        if c.lower() == "inspection lot qty"
    ]

    if exact_match:

        weight_col = exact_match[0]

    else:

        qty_cols = [
            c
            for c in raw.columns
            if "qty" in c.lower()
        ]

        if qty_cols:

            weight_col = qty_cols[0]

    weight_map = pd.Series(dtype=float)

    if weight_col:

        clean_text = (
            raw[weight_col]
            .astype(str)
            .str.replace(",", "")
        )

        extracted = clean_text.str.extract(
            r"(\d+\.?\d*)"
        )[0]

        raw["_Clean_Wt"] = pd.to_numeric(
            extracted,
            errors="coerce"
        )

        weight_map = (
            raw
            .dropna(subset=["_Clean_Wt"])
            .drop_duplicates("Inspection Lot")
            .set_index("Inspection Lot")
            ["_Clean_Wt"]
        )

    frames = []

    for source_name, output_name in PARAMS.items():

        subset = raw[
            raw["Check Point Desc"]
            == source_name
        ][
            [
                "Inspection Lot",
                "Inspection Lot Date",
                "Material Number",
                "Material Description",
                "Supplier Name",
                "Result Recorded",
                "Lower Limit",
                "Upper Limit",
            ]
        ].rename(
            columns={
                "Result Recorded": output_name,
                "Lower Limit": f"{output_name}_LL",
                "Upper Limit": f"{output_name}_UL",
            }
        )

        frames.append(subset)

    pivot = frames[0]

    for frame in frames[1:]:

        pivot = pivot.merge(
            frame,
            on=[
                "Inspection Lot",
                "Inspection Lot Date",
                "Material Number",
                "Material Description",
                "Supplier Name",
            ],
            how="outer",
        )

    if not weight_map.empty:

        pivot["Inspection Lot Qty"] = (
            pivot["Inspection Lot"]
            .map(weight_map)
        )

    pivot["TSYP"] = np.where(
        (
            pivot["Yield_Point"]
            > 0
        )
        &
        (
            pivot["Yield_Point"]
            .notna()
        ),
        pivot["UTS"]
        /
        pivot["Yield_Point"],
        np.nan,
    )

    pivot = pivot.dropna(
        subset=["Inspection Lot Date"]
    )

    return pivot