import numpy as np


def calculate_kpis(df):

    avg_weight = 0

    if (
        "Inspection Lot Qty"
        in df.columns
        and
        not df.empty
    ):

        avg_weight = (
            df["Inspection Lot Qty"]
            .mean()
            / 1000
        )

    return {

        "avg_weight":
        round(avg_weight, 2),

        "avg_tsyp":
        round(
            df["TSYP"].mean(),
            2
        ),

        "std_tsyp":
        round(
            df["TSYP"].std(),
            2
        ),

        "avg_yield_point":
        round(
            df["Yield_Point"].mean(),
            2
        ),

        "avg_uts":
        round(
            df["UTS"].mean(),
            2
        ),

        "avg_elongation":
        round(
            df["Elongation"].mean(),
            2
        ),

        "avg_carbon":
        round(
            df["Carbon_pct"].mean(),
            4
        ),
    }