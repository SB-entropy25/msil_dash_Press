import pandas as pd

from services.alerts import (
    generate_oos_mask,
    generate_warning_mask,
)
def get_daily_monitor(df):

    lots = 0
    materials = 0
    suppliers = 0

    if "Inspection Lot" in df.columns:

        lots = int(
            df["Inspection Lot"]
            .nunique()
        )

    if "Material Number" in df.columns:

        materials = int(
            df["Material Number"]
            .nunique()
        )

    if "Supplier Name" in df.columns:

        suppliers = int(
            df["Supplier Name"]
            .nunique()
        )

    oos_count = int(
        generate_oos_mask(df).sum()
    )

    warning_count = int(
        (
            generate_warning_mask(df)
            &
            ~generate_oos_mask(df)
        ).sum()
    )

    return {

        "lots_received":
        lots,

        "materials":
        materials,

        "suppliers":
        suppliers,

        "oos_lots":
        oos_count,

        "warning_lots":
        warning_count
    }
def get_supplier_intake(df):

    if df.empty:

        return []

    supplier_df = (
        df.groupby(
            "Supplier Name"
        )
        .agg(
            lots=(
                "Inspection Lot",
                "nunique"
            ),
            materials=(
                "Material Number",
                "nunique"
            )
        )
        .reset_index()
    )

    supplier_df = (
        supplier_df
        .sort_values(
            "lots",
            ascending=False
        )
    )

    return supplier_df.to_dict(
        orient="records"
    )
def get_materials_processed(df):

    if df.empty:

        return []

    mat_df = (
        df.groupby(
            [
                "Material Number",
                "Material Description"
            ]
        )
        .agg(
            lots=(
                "Inspection Lot",
                "nunique"
            )
        )
        .reset_index()
    )

    mat_df = (
        mat_df
        .sort_values(
            "lots",
            ascending=False
        )
    )

    return mat_df.to_dict(
        orient="records"
    )