import pandas as pd


def apply_filters(
    df,
    materials=None,
    suppliers=None,
    start_date=None,
    end_date=None,
):

    filtered = df.copy()

    if materials:
        filtered = filtered[
            filtered["Material Number"].isin(materials)
        ]

    if suppliers:
        filtered = filtered[
            filtered["Supplier Name"].isin(suppliers)
        ]

    # Handle Swagger default value "string"
    if (
        start_date
        and start_date != "string"
        and str(start_date).strip() != ""
    ):
        filtered = filtered[
            filtered["Inspection Lot Date"]
            >= pd.to_datetime(start_date)
        ]

    if (
        end_date
        and end_date != "string"
        and str(end_date).strip() != ""
    ):
        filtered = filtered[
            filtered["Inspection Lot Date"]
            <= pd.to_datetime(end_date)
        ]

    return filtered