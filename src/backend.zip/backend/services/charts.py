import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
def fig_to_json(fig):

    return fig.to_json()
def yield_point_trend(df):

    chart_df = (
        df.sort_values(
            "Inspection Lot Date"
        )
    )

    fig = px.line(
        chart_df,
        x="Inspection Lot Date",
        y="Yield_Point",
        color="Supplier Name",
        markers=True,
        title="Yield Point Trend",
    )

    return fig_to_json(fig)
def yield_point_distribution(df):

    fig = px.histogram(
        df,
        x="Yield_Point",
        nbins=30,
        title="Yield Point Distribution",
    )

    return fig_to_json(fig)
def uts_trend(df):

    chart_df = (
        df.sort_values(
            "Inspection Lot Date"
        )
    )

    fig = px.line(
        chart_df,
        x="Inspection Lot Date",
        y="UTS",
        color="Supplier Name",
        markers=True,
        title="UTS Trend",
    )

    return fig_to_json(fig)
def uts_distribution(df):

    fig = px.histogram(
        df,
        x="UTS",
        nbins=30,
        title="UTS Distribution",
    )

    return fig_to_json(fig)
def carbon_trend(df):

    fig = px.line(
        df.sort_values(
            "Inspection Lot Date"
        ),
        x="Inspection Lot Date",
        y="Carbon_pct",
        color="Supplier Name",
        markers=True,
        title="Carbon Trend",
    )

    return fig_to_json(fig)
def carbon_distribution(df):

    fig = px.histogram(
        df,
        x="Carbon_pct",
        nbins=30,
        title="Carbon Distribution",
    )

    return fig_to_json(fig)
def elongation_trend(df):

    fig = px.line(
        df.sort_values(
            "Inspection Lot Date"
        ),
        x="Inspection Lot Date",
        y="Elongation",
        color="Supplier Name",
        markers=True,
        title="Elongation Trend",
    )

    return fig_to_json(fig)
def tsyp_trend(df):

    fig = px.line(
        df.sort_values(
            "Inspection Lot Date"
        ),
        x="Inspection Lot Date",
        y="TSYP",
        color="Supplier Name",
        markers=True,
        title="TSYP Trend",
    )

    return fig_to_json(fig)
def tsyp_distribution(df):

    fig = px.histogram(
        df,
        x="TSYP",
        nbins=30,
        title="TSYP Distribution",
    )

    return fig_to_json(fig)
def yield_vs_uts(df):

    fig = px.scatter(
        df,
        x="Yield_Point",
        y="UTS",
        color="Supplier Name",
        title="Yield Point vs UTS",
    )

    return fig_to_json(fig)
def supplier_comparison(df):

    supplier_df = (
        df.groupby(
            "Supplier Name"
        )
        .agg(
            Yield_Point=(
                "Yield_Point",
                "mean"
            ),
            UTS=(
                "UTS",
                "mean"
            )
        )
        .reset_index()
    )

    fig = go.Figure()

    fig.add_bar(
        x=supplier_df["Supplier Name"],
        y=supplier_df["Yield_Point"],
        name="Yield Point"
    )

    fig.add_bar(
        x=supplier_df["Supplier Name"],
        y=supplier_df["UTS"],
        name="UTS"
    )

    return fig_to_json(fig)
def get_chart(
    chart_name,
    df
):

    chart_map = {

        "yield_point_trend":
        yield_point_trend,

        "yield_point_distribution":
        yield_point_distribution,

        "uts_trend":
        uts_trend,

        "uts_distribution":
        uts_distribution,

        "elongation_trend":
        elongation_trend,

        "carbon_trend":
        carbon_trend,

        "carbon_distribution":
        carbon_distribution,

        "tsyp_trend":
        tsyp_trend,

        "tsyp_distribution":
        tsyp_distribution,

        "yield_vs_uts":
        yield_vs_uts,

        "supplier_comparison":
        supplier_comparison,
    }

    if chart_name not in chart_map:
        return {
            "error": f"Unknown chart name: {chart_name}",
            "available_charts": list(chart_map.keys())
        }

    return chart_map[chart_name](df)