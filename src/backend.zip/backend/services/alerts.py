import pandas as pd


def generate_oos_mask(df):

    mask = pd.Series(
        False,
        index=df.index
    )

    if (
        "Yield_Point" in df.columns
        and "Yield_Point_UL" in df.columns
    ):
        mask |= (
            df["Yield_Point"]
            >=
            df["Yield_Point_UL"]
        )

    if (
        "Carbon_pct" in df.columns
        and "Carbon_pct_UL" in df.columns
    ):
        mask |= (
            df["Carbon_pct"]
            >=
            df["Carbon_pct_UL"]
        )

    if (
        "Elongation" in df.columns
        and "Elongation_LL" in df.columns
    ):
        mask |= (
            df["Elongation"]
            <=
            df["Elongation_LL"]
        )

    if (
        "UTS" in df.columns
        and "UTS_LL" in df.columns
        and "UTS_UL" in df.columns
    ):
        mask |= (
            (
                df["UTS"]
                <=
                df["UTS_LL"]
            )
            |
            (
                df["UTS"]
                >=
                df["UTS_UL"]
            )
        )

    if "TSYP" in df.columns:
        mask |= (
            df["TSYP"]
            < 1.15
        )

    return mask
def generate_warning_mask(df):

    mask = pd.Series(
        False,
        index=df.index
    )

    if (
        "Yield_Point" in df.columns
        and "Yield_Point_UL" in df.columns
    ):
        mask |= (
            df["Yield_Point"]
            >=
            (
                0.9
                *
                df["Yield_Point_UL"]
            )
        )

    if (
        "Carbon_pct" in df.columns
        and "Carbon_pct_UL" in df.columns
    ):
        mask |= (
            df["Carbon_pct"]
            >=
            (
                0.9
                *
                df["Carbon_pct_UL"]
            )
        )

    if (
        "Elongation" in df.columns
        and "Elongation_LL" in df.columns
    ):
        mask |= (
            df["Elongation"]
            <=
            (
                1.1
                *
                df["Elongation_LL"]
            )
        )

    if "TSYP" in df.columns:

        mask |= (
            (
                df["TSYP"]
                >= 1.15
            )
            &
            (
                df["TSYP"]
                <= 1.20
            )
        )

    return mask
def get_alert_summary(df):

    oos_mask = generate_oos_mask(df)

    warning_mask = (
        generate_warning_mask(df)
        &
        ~oos_mask
    )

    return {

        "critical_count":
        int(
            oos_mask.sum()
        ),

        "warning_count":
        int(
            warning_mask.sum()
        ),

        "total_records":
        int(
            len(df)
        )
    }
def get_oos_records(df):

    mask = generate_oos_mask(df)

    cols = [
        c
        for c in [
            "Inspection Lot",
            "Material Number",
            "Supplier Name",
            "Inspection Lot Date",
            "TSYP"
        ]
        if c in df.columns
    ]

    return (
        df.loc[
            mask,
            cols
        ]
        .sort_values(
            "Inspection Lot Date",
            ascending=False
        )
        .to_dict(
            orient="records"
        )
    )
def get_warning_records(df):

    oos_mask = generate_oos_mask(df)

    warning_mask = (
        generate_warning_mask(df)
        &
        ~oos_mask
    )

    cols = [
        c
        for c in [
            "Inspection Lot",
            "Material Number",
            "Supplier Name",
            "Inspection Lot Date",
            "TSYP"
        ]
        if c in df.columns
    ]

    return (
        df.loc[
            warning_mask,
            cols
        ]
        .sort_values(
            "Inspection Lot Date",
            ascending=False
        )
        .to_dict(
            orient="records"
        )
    )