import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import numpy as np
from scipy import stats as scipy_stats
import time
import base64
import os

# ------------------
# PAGE CONFIGURATION (Must be first)
# ------------------
st.set_page_config(
    page_title="Material Inspection Dashboard Press Shop",
    page_icon="🏭",
    layout="wide",
    initial_sidebar_state="expanded"
)

# # ------------------
# # BASE64 TOOLBAR CONVERTER
# # ------------------
# def get_base64_image(image_path):
#     if os.path.exists(image_path):
#         with open(image_path, "rb") as img_file:
#             return base64.b64encode(img_file.read()).decode()
#     return None

# header_b64 = get_base64_image("data/iot_header.png")
# if header_b64:
#     HEADER_CSS = f"""
#         background-color: #ffffff !important; /* Fills the rest of the bar with white */
#         background-image: url('data:image/png;base64,{header_b64}') !important;
#         background-size: contain !important; /* Stops the stretching */
#         background-position: center !important;
#         background-repeat: no-repeat !important;
#         height: 70px !important;
#         box-shadow: 0 2px 10px rgba(0,0,0,0.2) !important;
#     """
# else:
#     HEADER_CSS = "background: transparent !important;"
#     st.warning("Toolbar image not found at data/iot_header.png")

# ------------------
# THEME & STATE INIT
# ------------------
if "theme" not in st.session_state:
    st.session_state.theme = "dark"

if "show_right_panel" not in st.session_state:
    st.session_state.show_right_panel = True

if "slide_index" not in st.session_state:
    st.session_state.slide_index = 0

# # ------------------
# # AUTHENTICATION
# # ------------------
# if "authenticated" not in st.session_state:
#     st.session_state.authenticated = False

# def authenticate(username, password):
#     try:
#         users = pd.read_excel("data/users.xlsx")
#         match = users[
#             (users["username"] == username) &
#             (users["password"] == password)
#         ]
#         return len(match) > 0
#     except:
#         return username == "admin" and password == "admin"

# if not st.session_state.authenticated:
#     is_light_auth = st.session_state.theme == "light"

#     if is_light_auth:
#         auth_css = f"""<style>
#         @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
#         html, body, [class*="css"] {{ font-family: 'Inter', sans-serif; }}
#         [data-testid="stAppViewContainer"] {{ background-color: #f5f7fa; }}
#         [data-testid="stHeader"] {{ {HEADER_CSS} }}
#         .block-container {{ padding-top: 6rem !important; }}
#         .stTextInput>div>div>input {{ background:#fff; color:#1a1a2e; border:1px solid #d0d7de; border-radius: 6px; }}
#         .stButton>button {{ background:#0052cc; color:#fff; border-radius:8px; width:100%; font-weight: 600; padding: 0.6rem; transition: 0.2s; }}
#         .stButton>button:hover {{ background:#003d99; transform: translateY(-2px); box-shadow: 0 4px 10px rgba(0,82,204,0.2); }}
#         h1, h2, h3, p, label {{ color: #1a1a2e !important; }}
#         </style>"""
#     else:
#         auth_css = f"""<style>
#         @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
#         html, body, [class*="css"] {{ font-family: 'Inter', sans-serif; }}
#         [data-testid="stAppViewContainer"] {{ background-color: #0d1117; }}
#         [data-testid="stHeader"] {{ {HEADER_CSS} }}
#         .block-container {{ padding-top: 6rem !important; }}
#         .stTextInput>div>div>input {{ background:#161b22; color:#e6f1ff; border:1px solid #30363d; border-radius: 6px; }}
#         .stButton>button {{ background:#64ffda15; color:#64ffda; border:1px solid #64ffda55; border-radius:8px; width:100%; font-weight: 600; padding: 0.6rem; transition: 0.2s; }}
#         .stButton>button:hover {{ background:#64ffda33; border:1px solid #64ffda; transform: translateY(-2px); box-shadow: 0 4px 10px rgba(100,255,218,0.15); }}
#         h1, h2, h3, p, label {{ color: #e6f1ff !important; }}
#         </style>"""

#     st.markdown(auth_css, unsafe_allow_html=True)

#     tcol1, tcol2, tcol3 = st.columns([1, 2, 1])
#     with tcol3:
#         toggle_lbl = "☀️ Light Mode" if not is_light_auth else "🌙 Dark Mode"
#         if st.button(toggle_lbl, key="auth_theme"):
#             st.session_state.theme = "light" if not is_light_auth else "dark"
#             st.rerun()

#     col1, col2, col3 = st.columns([1, 2, 1])
#     with col2:
#         st.markdown("<br><br>", unsafe_allow_html=True)
#         try:
#             st.image("data/msil_logo.png", width=250)
#         except:
#             st.markdown("<h2>🏭 MSIL</h2>", unsafe_allow_html=True)
#         st.markdown("<h1 style='margin-bottom: 0px;'>Login</h1>", unsafe_allow_html=True)
#         st.markdown("<p style='opacity: 0.7; font-size: 14px; margin-bottom: 20px;'>Maruti Suzuki Quality Analytics</p>", unsafe_allow_html=True)

#     username = st.text_input("Username")
#     password = st.text_input("Password", type="password")

#     if st.button("Secure Login"):
#         if authenticate(username, password):
#             st.session_state.authenticated = True
#             st.rerun()
#         else:
#             st.error("Invalid username or password")

#     st.stop()

# ------------------
# DASHBOARD
# ------------------

# ── Theme Variables ────────────────────────────────────────────────────────────
IS_LIGHT = st.session_state.theme == "light"

if IS_LIGHT:
    PLOT_BG  = "#ffffff"
    PAPER_BG = "#ffffff"
    GRID_CLR = "#e8ecf0"
    FONT_CLR = "#000000"  
    ACCENT   = "#0052cc"
    PRIM_TXT = "#ffffff"
    H1_CLR   = "#1a1a2e"
    H2_CLR   = "#2d3748"
    MAIN_BG  = "#f5f7fa"
    SIDEBAR_BG="#ffffff"
    HR_CLR   = "#d0d7de"
    FOOTER_CLR="#a0aec0"
    LEGEND_BG= "rgba(245,247,250,0.95)"
    LEGEND_BR= "#d0d7de"
    CARD_BG  = "#ffffff"
    CARD_BR  = "#d0d7de"
    CARD_LBL = "#6b7a9c"
    CARD_VAL = "#0052cc"
    CARD_SUB = "#718096"
    MON_BG   = "#ffffff"
    MON_BR   = "#0052cc"
    MON_HD   = "#1a1a2e"
    MON_BIG  = "#0052cc"
    MON_SUB  = "#4a5568"
    MON_SEC  = "#4a5568"
    MON_CHIP_BG="#f5f7fa"
    MON_CHIP_BR="#d0d7de"
    MON_CHIP_CLR="#2d3748"
    MON_CHIP_ID="#0052cc"
    MON_CHIP_DS="#6b7a9c"
    MON_SUP_BG="#f0fff4"
    MON_SUP_BR="#38a169"
    MON_SUP_CLR="#276749"
    MON_DATE_BG="#f5f7fa"
    MON_DATE_BR="#d0d7de"
    EMPTY_CLR="#a0aec0"
    ALERT_BG ="#fff5f5"
    ALERT_BR ="1px solid #feb2b2"
    ALERT_BL ="4px solid #e53e3e"
    ALERT_TT ="#c53030"
    ALERT_BODY="#2d3748"
    ALERT_W_BG="#fffff0"
    ALERT_W_BR="1px solid #fef08a"
    ALERT_W_BL="4px solid #d69e2e"
    ALERT_W_TT="#b7791f"
    SEC_TTL  = "#1a1a2e"
    COLORS   = ["#0052cc","#e53e3e","#d69e2e","#2b6cb0","#805ad5","#c05621",
                "#276749","#b83280","#553c9a","#2c7a7b"]
else:
    PLOT_BG  = "#161b22"
    PAPER_BG = "#161b22"
    GRID_CLR = "#21262d"
    FONT_CLR = "#8b949e"
    ACCENT   = "#64ffda"
    PRIM_TXT = "#0d1117"
    H1_CLR   = "#ffffff"
    H2_CLR   = "#e6f1ff"
    MAIN_BG  = "#0d1117"
    SIDEBAR_BG="#161b22"
    HR_CLR   = "#30363d"
    FOOTER_CLR="#8b949e"
    LEGEND_BG= "rgba(22,27,34,0.85)"
    LEGEND_BR= "#30363d"
    CARD_BG  = "#161b22"
    CARD_BR  = "#30363d"
    CARD_LBL = "#8b949e"
    CARD_VAL = "#64ffda"
    CARD_SUB = "#6e7681"
    MON_BG   = "#161b22"
    MON_BR   = "#64ffda"
    MON_HD   = "#e6f1ff"
    MON_BIG  = "#64ffda"
    MON_SUB  = "#8b949e"
    MON_SEC  = "#8b949e"
    MON_CHIP_BG="#0d1117"
    MON_CHIP_BR="#30363d"
    MON_CHIP_CLR="#c9d1d9"
    MON_CHIP_ID="#64ffda"
    MON_CHIP_DS="#8b949e"
    MON_SUP_BG="#0d1117"
    MON_SUP_BR="#2ea043"
    MON_SUP_CLR="#7ee787"
    MON_DATE_BG="#0d1117"
    MON_DATE_BR="#30363d"
    EMPTY_CLR="#6e7681"
    ALERT_BG ="#2a1a1a"
    ALERT_BR ="1px solid #ff6b6b55"
    ALERT_BL ="4px solid #ff6b6b"
    ALERT_TT ="#ff6b6b"
    ALERT_BODY="#e6f1ff"
    ALERT_W_BG="#2a2210"
    ALERT_W_BR="1px solid #ffd93d55"
    ALERT_W_BL="4px solid #ffd93d"
    ALERT_W_TT="#ffd93d"
    SEC_TTL  = "#e6f1ff"
    COLORS   = ["#64ffda","#ff6b6b","#ffd93d","#6bcbf7","#c084fc","#f97316",
                "#34d399","#fb7185","#a78bfa","#38bdf8"]

# ── CSS ────────────────────────────────────────────────────────────────────────
st.markdown(f"""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
    
    html, body, [class*="css"] {{ font-family: 'Inter', sans-serif; }}
    [data-testid="stAppViewContainer"] {{ background-color: {MAIN_BG} !important; }}
    [data-testid="stSidebar"] > div:first-child {{ background-color: {SIDEBAR_BG} !important; border-right: 1px solid {HR_CLR}; }}
    
    /* Apply the global toolbar CSS */
    
    
    p, label, span, .stMarkdown, .stText {{ color: {FONT_CLR if not IS_LIGHT else '#1a1a2e'} !important; }}
    h1, h2, h3, h4, h5, h6, [data-testid="stMarkdownContainer"] h1 {{ color: {H1_CLR} !important; font-weight: 800; }}
    hr {{ border-color: {HR_CLR} !important; margin: 1.5rem 0; }}
    
    /* Push content down to avoid hiding under the fixed toolbar */
    .block-container {{ padding-top: 6rem !important; padding-bottom: 2rem; max-width: 98% !important; }}
    div[data-testid="stMetric"] {{ display: none; }}
    
    /* ── Native Streamlit Button Overrides ── */
    .stButton > button {{
        background-color: {CARD_BG} !important;
        color: {FONT_CLR if not IS_LIGHT else '#1a1a2e'} !important;
        border: 1px solid {CARD_BR} !important;
        border-radius: 6px;
        transition: all 0.2s ease;
        font-weight: 600;
    }}
    .stButton > button:hover {{
        border-color: {ACCENT} !important;
        color: {ACCENT} !important;
        background-color: transparent !important;
    }}
    .stButton > button[kind="primary"] {{
        background-color: {ACCENT} !important;
        color: {PRIM_TXT} !important;
        border: none !important;
    }}
    .stButton > button[kind="primary"]:hover {{
        opacity: 0.85;
        background-color: {ACCENT} !important;
        color: {PRIM_TXT} !important;
    }}

    /* ── Flexbox KPI Container ── */
    .kpi-container {{
        display: flex;
        flex-wrap: wrap;
        gap: 16px;
        margin-bottom: 24px;
        width: 100%;
    }}
    .kpi-wrapper {{
        flex: 1 1 calc(14.28% - 16px);
        min-width: 150px;
    }}

    /* ── Native Streamlit Expander Overrides ── */
    [data-testid="stExpander"] {{
        background-color: transparent !important;
        border: 1px solid {ALERT_TT}40 !important;
        border-radius: 8px;
        overflow: hidden;
    }}
    [data-testid="stExpander"] summary {{
        background-color: {ALERT_BG} !important;
        color: {ALERT_TT} !important;
        padding: 0.5rem 1rem !important;
    }}
    [data-testid="stExpander"] summary:hover {{
        opacity: 0.9;
    }}
    [data-testid="stExpander"] summary p {{
        color: {ALERT_TT} !important;
        font-weight: 800 !important;
        font-size: 15px;
    }}
    [data-testid="stExpander"] summary svg {{
        color: {ALERT_TT} !important;
    }}
    [data-testid="stExpanderDetails"] {{
        background-color: {MAIN_BG} !important;
        border-top: 1px solid {ALERT_TT}20 !important;
    }}

    .truncate {{
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        display: block;
    }}
    
    .metric-card {{
        background: {CARD_BG};
        border: 1px solid {CARD_BR}; 
        border-radius: 12px;
        padding: 24px 20px; 
        text-align: center;
        box-shadow: 0 4px 6px rgba(0,0,0,0.05);
        transition: transform 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease;
        display: flex;
        flex-direction: column;
        justify-content: center;
        height: 100%;
    }}
    .metric-card:hover {{
        transform: translateY(-4px);
        box-shadow: 0 8px 15px rgba(0,0,0,0.1);
        border-color: {MON_BR};
    }}
    .metric-label {{ 
        color: {CARD_LBL}; font-size: 12px; font-weight: 700;
        letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 8px; 
    }}
    .metric-value {{ 
        color: {CARD_VAL}; font-size: 32px; font-weight: 800; 
        white-space: nowrap; line-height: 1.2;
    }}
    .metric-sub {{ 
        color: {CARD_SUB}; font-size: 12px; margin-top: 6px; font-weight: 500;
    }}
    
    .alert-card {{
        background: {ALERT_BG};
        border: {ALERT_BR}; border-left: {ALERT_BL};
        border-radius: 8px; padding: 16px 20px; margin-bottom: 12px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }}
    .alert-card-warn {{
        background: {ALERT_W_BG};
        border: {ALERT_W_BR}; border-left: {ALERT_W_BL};
        border-radius: 8px; padding: 16px 20px; margin-bottom: 12px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }}
    .alert-title {{ 
        color: {ALERT_TT}; font-size: 13px; font-weight: 800;
        text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 6px;
    }}
    .alert-title-warn {{ 
        color: {ALERT_W_TT}; font-size: 13px; font-weight: 800;
        text-transform: uppercase; letter-spacing: 0.08em; margin-bottom: 6px;
    }}
    .alert-body {{ color: {ALERT_BODY}; font-size: 14px; line-height: 1.5; }}
    
    .section-title {{ 
        color: {SEC_TTL}; font-size: 16px; font-weight: 800;
        letter-spacing: 0.05em; margin-bottom: 16px; margin-top: 16px; text-transform: uppercase; 
    }}
    
    .monitor-panel {{
        background: {MON_BG};
        border: 1px solid {CARD_BR}; border-top: 4px solid {MON_BR};
        border-radius: 12px; padding: 24px 20px; position: sticky; top: 5rem;
        box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    }}
    .monitor-header {{
        color: {MON_HD}; font-size: 14px; font-weight: 800;
        letter-spacing: 0.05em; text-transform: uppercase;
        border-bottom: 1px solid {CARD_BR}; padding-bottom: 12px; margin-bottom: 16px;
    }}
    .monitor-big {{ 
        color: {MON_BIG}; font-size: 48px; font-weight: 800;
        text-align: center; line-height: 1; margin-top: 10px;
    }}
    .monitor-sub {{ 
        color: {MON_SUB}; font-size: 11px; font-weight: 700;
        text-transform: uppercase; letter-spacing: 0.1em; text-align: center; margin-bottom: 24px; margin-top: 8px;
    }}
    .monitor-section {{ 
        color: {MON_SEC}; font-size: 11px; font-weight: 800;
        text-transform: uppercase; letter-spacing: 0.08em; margin: 24px 0 12px 0; border-bottom: 1px dashed {CARD_BR}; padding-bottom: 4px;
    }}
    .monitor-chip {{
        background: {MON_CHIP_BG}; border: 1px solid {MON_CHIP_BR};
        border-radius: 8px; padding: 10px 12px; margin-bottom: 8px;
        transition: transform 0.2s ease;
    }}
    .monitor-chip:hover {{ transform: translateX(4px); }}
    .monitor-chip-id {{ color: {MON_CHIP_ID}; font-weight: 800; font-size: 11px; display: inline-block; margin-bottom: 4px; }}
    .monitor-chip-desc {{ color: {MON_CHIP_DS}; font-size: 11px; font-weight: 500; }}
    
    .monitor-supplier-chip {{
        background: {MON_SUP_BG}; border: 1px solid {MON_SUP_BR}40;
        border-left: 3px solid {MON_SUP_BR}; border-radius: 8px;
        padding: 10px 12px; margin-bottom: 8px; color: {MON_SUP_CLR};
        transition: transform 0.2s ease;
    }}
    .monitor-supplier-chip:hover {{ transform: translateX(4px); }}
    
    .monitor-date-box {{
        background: {MON_DATE_BG}; border: 1px solid {MON_DATE_BR};
        border-radius: 8px; padding: 12px; margin-bottom: 16px;
    }}
    .empty-monitor {{ 
        color: {EMPTY_CLR}; font-size: 13px;
        text-align: center; padding: 20px 0; font-style: italic; 
    }}
</style>
""", unsafe_allow_html=True)

# ── Constants ──────────────────────────────────────────────────────────────────
PARAMS = {
    "YIELD POINT":               "Yield_Point",
    "% ELONGATION":              "Elongation",
    "ULTIMATE TENSILE STRENGTH": "UTS",
    "% CARBON":                  "Carbon_pct",
}
PARAM_LABELS = {
    "Yield_Point": "Yield Point (MPa)",
    "Elongation":  "Elongation (%)",
    "UTS":         "UTS (MPa)",
    "Carbon_pct":  "Carbon (%)",
}

TOOLTIPS = {
    "Yield Point": "Safe: <90% of UL | Caution: 90-100% of UL | Critical: ≥UL",
    "Yield Point Normal Dist": "Normal distribution of Yield Point with individual lot mappings.",
    "Ultimate Tensile Strength": "Safe: Center 70% of tolerance band | Caution: Outer 15% margins | Critical: ≤LL or ≥UL",
    "UTS Normal Dist": "Normal distribution of Ultimate Tensile Strength with individual lot mappings.",
    "Elongation": "Safe: >110% of LL | Caution: 100-110% of LL | Critical: ≤LL",
    "Carbon %": "Safe: <90% of UL | Caution: 90-100% of UL | Critical: ≥UL",
    "Carbon % Normal Dist": "Normal distribution of Carbon % with individual lot mappings.",
    "TSYP Trend": "Safe: >1.20 | Caution: 1.15-1.20 | Critical: <1.15",
    "TSYP Bar Charts": "Higher TSYP indicates better formability. TSYP > 1.20 is preferred.",
    "TSYP Distribution": "Safe: >1.20 | Caution: 1.15-1.20 | Critical: <1.15",
    "Yield Point vs UTS": "TSYP > 1.20 preferred (points well above the line).",
    "Yield Point & UTS by Supplier": "Supplier comparison of key strength metrics."
}

# ── Data loading ───────────────────────────────────────────────────────────────
@st.cache_data
def load_data():
    try:
        raw = pd.read_excel("data/Master_File.xlsx", header=1)
    except:
        st.error("Data file not found. Ensure 'data/Master_File.xlsx' exists.")
        st.stop()
        
    raw = raw.dropna(how="all")
    raw.columns = raw.columns.str.strip()
    raw["Inspection Lot Date"] = pd.to_datetime(raw["Inspection Lot Date"], format="%d.%m.%Y", errors="coerce")
    raw["Result Recorded"] = pd.to_numeric(raw["Result Recorded"], errors="coerce")
    raw["Lower Limit"]     = pd.to_numeric(raw["Lower Limit"],     errors="coerce")
    raw["Upper Limit"]     = pd.to_numeric(raw["Upper Limit"],     errors="coerce")
    raw["Inspection Lot"]  = pd.to_numeric(raw["Inspection Lot"],  errors="coerce")
    
    # --- BULLETPROOF WEIGHT EXTRACTION (COMMAS FIXED) ---
    exact_match = [c for c in raw.columns if c.lower() == "inspection lot qty"]
    if exact_match:
        weight_col = exact_match[0]
    else:
        fallback = [c for c in raw.columns if "qty" in c.lower()]
        weight_col = fallback[0] if fallback else None

    weight_map = pd.Series(dtype=float)
    
    if weight_col:
        clean_text = raw[weight_col].astype(str).str.replace(',', '', regex=False)
        extracted_nums = clean_text.str.extract(r'(\d+\.?\d*)')[0]
        raw["_Clean_Wt"] = pd.to_numeric(extracted_nums, errors="coerce")
        weight_map = raw.dropna(subset=["_Clean_Wt"]).drop_duplicates("Inspection Lot").set_index("Inspection Lot")["_Clean_Wt"]

    dfs = []
    for raw_key, col_name in PARAMS.items():
        cols_to_keep = [
            "Inspection Lot","Inspection Lot Date","Material Number",
            "Material Description","Supplier Name","Result Recorded","Lower Limit","Upper Limit"
        ]
        cols_to_keep = [c for c in cols_to_keep if c in raw.columns]
        
        sub = raw[raw["Check Point Desc"] == raw_key][cols_to_keep].rename(columns={
            "Result Recorded": col_name,
            "Lower Limit":     f"{col_name}_LL",
            "Upper Limit":     f"{col_name}_UL",
        })
        dfs.append(sub)

    pivot = dfs[0]
    for d in dfs[1:]:
        pivot = pivot.merge(d, on=["Inspection Lot","Inspection Lot Date",
                                    "Material Number","Material Description","Supplier Name"],
                            how="outer")

    if not weight_map.empty:
        pivot["Inspection Lot Qty"] = pivot["Inspection Lot"].map(weight_map)
    else:
        pivot["Inspection Lot Qty"] = np.nan

    pivot["TSYP"] = np.where(
        (pivot["Yield_Point"] > 0) & pivot["Yield_Point"].notna(),
        pivot["UTS"] / pivot["Yield_Point"], np.nan
    )
    pivot = pivot.dropna(subset=["Inspection Lot Date"]).sort_values("Inspection Lot Date")
    pivot["Inspection Lot"] = pivot["Inspection Lot"].astype(str)
    pivot["Supplier Name"]  = pivot["Supplier Name"].str.strip()
    return pivot

df = load_data()

mat_to_desc  = df.drop_duplicates("Material Number").set_index("Material Number")["Material Description"].to_dict()
desc_to_mat  = {v: k for k, v in mat_to_desc.items()}
all_materials    = sorted(df["Material Number"].dropna().unique())
all_descriptions = sorted(df["Material Description"].dropna().unique())
all_suppliers    = sorted(df["Supplier Name"].dropna().unique())

def format_mat_code(mat_code):
    desc = mat_to_desc.get(mat_code, "")
    return f"{mat_code} - {desc}" if desc else mat_code

# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    try:
        st.image("data/msil_logo.png")
    except:
        pass
    st.markdown("<br>", unsafe_allow_html=True)
    if st.button("🔄 Fetch Latest Data", type="primary", use_container_width=True):
        st.cache_data.clear() 
        st.rerun()            
        
    st.markdown("---")

    toggle_icon = "☀️ Switch to Light Mode" if not IS_LIGHT else "🌙 Switch to Dark Mode"
    if st.button(toggle_icon, key="dash_theme_toggle", use_container_width=True):
        st.session_state.theme = "light" if not IS_LIGHT else "dark"
        st.rerun()

    st.markdown("---")
    st.markdown("<h3 style='margin:0; font-size:16px'>🔧 Controls & Filters</h3>", unsafe_allow_html=True)
    st.markdown("<br>", unsafe_allow_html=True)

    filter_mode = st.radio(
        "Filter Mode",
        ["Material Number", "Supplier"],
        horizontal=False
    )
    if filter_mode == "Material Number":
        selected_ids = st.multiselect("Material Number", options=all_materials, default=all_materials[:5], format_func=format_mat_code)
        selected_materials = list(set(selected_ids)) if selected_ids else []
        selected_suppliers = all_suppliers
    else:
        selected_suppliers = st.multiselect("Supplier", options=all_suppliers, default=all_suppliers[:3])
        selected_materials = all_materials

    st.markdown("---")
    min_date = df["Inspection Lot Date"].min().date()
    max_date = df["Inspection Lot Date"].max().date()
    date_range = st.date_input("Inspection Date Range", value=(min_date, max_date),
                                min_value=min_date, max_value=max_date)
    st.markdown("---")
    
    st.markdown("**Chart Overlays & Alerts**")
    show_limits   = st.toggle("Show Spec Limit Lines",   value=True)
    show_outliers = st.toggle("Show Outlier Highlights", value=True)
    show_zones    = st.toggle("Show Zone Shading",       value=True)
    show_hover    = st.toggle("Show Detailed Hover Info",value=True)
    show_alerts   = st.toggle("Show OOS & Action Required Alerts", value=False)
    
    st.markdown("---")
    st.markdown(f"<div style='font-size:12px; color:{CARD_SUB}; line-height:1.6;'>"
                f"<b>Dataset:</b> Master_Data<br>"
                f"<b>Total Lots:</b> {df['Inspection Lot'].nunique():,}<br>"
                f"<b>Materials:</b> {df['Material Number'].nunique()}<br>"
                f"<b>Date Span:</b><br>{min_date} → {max_date}</div>", unsafe_allow_html=True)

# ── Apply filters ──────────────────────────────────────────────────────────────
if len(date_range) == 2:
    s_date, e_date = pd.Timestamp(date_range[0]), pd.Timestamp(date_range[1])
else:
    s_date, e_date = pd.Timestamp(min_date), pd.Timestamp(max_date)

if not selected_materials:
    st.warning("No materials selected.")
    st.stop()
if not selected_suppliers:
    st.warning("No suppliers selected.")
    st.stop()

filtered = df[
    df["Material Number"].isin(selected_materials) &
    df["Supplier Name"].isin(selected_suppliers) &
    (df["Inspection Lot Date"] >= s_date) &
    (df["Inspection Lot Date"] <= e_date)
].copy().sort_values("Inspection Lot")

if filtered.empty:
    st.warning("No data for the selected filters.")
    st.stop()

def display_name(mat):
    return format_mat_code(mat)

# ── Helpers (Updated with 0-70-90-100 logic & Supplier Name) ────────────────────
def base_layout(fig, yaxis2=False):
    upd = dict(
        paper_bgcolor=PAPER_BG, plot_bgcolor=PLOT_BG,
        font=dict(color=FONT_CLR, size=12, family="Inter"),
        margin=dict(l=60, r=40, t=60, b=120),
        legend=dict(bgcolor=LEGEND_BG, bordercolor=LEGEND_BR, borderwidth=1,
                    font=dict(size=11, color=FONT_CLR), orientation="h", yanchor="top", y=-0.35,
                    xanchor="center", x=0.5, traceorder="normal", itemsizing="constant"),
        hovermode="closest",
        xaxis=dict(gridcolor=GRID_CLR, linecolor=CARD_BR, tickfont=dict(size=11, color=FONT_CLR), tickangle=-45, title_font=dict(color=FONT_CLR, weight="bold")),
        yaxis=dict(gridcolor=GRID_CLR, linecolor=CARD_BR, tickfont=dict(size=11, color=FONT_CLR), title_font=dict(color=FONT_CLR, weight="bold"), autorange=True),
    )
    if yaxis2:
        upd["yaxis2"] = dict(gridcolor=GRID_CLR, linecolor=CARD_BR, overlaying="y", side="right", tickfont=dict(size=11, color=FONT_CLR))
    fig.update_layout(**upd)
    return fig

def spec_stats(data, col):
    ll, ul = np.nan, np.nan
    ll_col, ul_col = f"{col}_LL", f"{col}_UL"
    if ll_col in data.columns:
        v = data[ll_col].dropna()
        if not v.empty: ll = v.min()
    if ul_col in data.columns:
        v = data[ul_col].dropna()
        if not v.empty: ul = v.max() 
    return ll, ul

def spec_outlier_mask(data, col):
    vals = data[col]
    mask = pd.Series(False, index=data.index)
    if col in ["Yield_Point", "Carbon_pct"]:
        ul_col = f"{col}_UL"
        if ul_col in data.columns:
            mask |= vals.notna() & data[ul_col].notna() & (vals >= data[ul_col])
    elif col == "Elongation":
        ll_col = f"{col}_LL"
        if ll_col in data.columns:
            mask |= vals.notna() & data[ll_col].notna() & (vals <= data[ll_col])
    elif col == "UTS":
        ll_col, ul_col = f"{col}_LL", f"{col}_UL"
        if ll_col in data.columns and ul_col in data.columns:
            mask |= vals.notna() & data[ll_col].notna() & data[ul_col].notna() & ((vals <= data[ll_col]) | (vals >= data[ul_col]))
    elif col == "TSYP":
        mask |= vals.notna() & (vals < 1.15)
    return mask

def add_spec_lines(fig, ll, ul):
    if not show_limits: return fig
    if pd.notna(ll) and pd.notna(ul):
        mean = (ll + ul) / 2
        fig.add_hline(y=mean, line_dash="dot", line_color=FONT_CLR, line_width=1.5, opacity=0.7,
                      annotation_text=f"— Mean = {mean:.2f}",
                      annotation_font=dict(color=FONT_CLR, size=11, weight="bold"), annotation_position="top left")
    if pd.notna(ll):
        fig.add_hline(y=ll, line_dash="dash", line_color="#ff6b6b", line_width=1.5, opacity=0.85,
                      annotation_text=f"▼ Lower Spec Limit (LL) = {ll:.2f}",
                      annotation_font=dict(color="#ff6b6b", size=11, weight="bold"), annotation_position="bottom right")
    if pd.notna(ul):
        fig.add_hline(y=ul, line_dash="dash", line_color="#ff6b6b", line_width=1.5, opacity=0.85,
                      annotation_text=f"▲ Upper Spec Limit (UL) = {ul:.2f}",
                      annotation_font=dict(color="#ff6b6b", size=11, weight="bold"), annotation_position="top right")
    return fig

def add_zone_shading(fig, col, ll, ul, data_series):
    if not show_zones: return fig
    zones = []
    d_min = data_series.min() if not data_series.empty else 0
    d_max = data_series.max() if not data_series.empty else 100
    pad = (d_max - d_min) * 0.15 if d_max != d_min else d_max * 0.15
    if pad == 0: pad = 10
    
    y_top = d_max + pad
    y_bot = max(0, d_min - pad)
    if pd.notna(ul): y_top = max(y_top, ul + pad)
    if pd.notna(ll): y_bot = min(y_bot, max(0, ll - pad))

    if col in ["Yield_Point", "Carbon_pct"] and pd.notna(ul):
        zones.append((y_bot, 0.90 * ul, "rgba(46,160,67,0.08)", "Safe (<90% UL)"))
        zones.append((0.90 * ul, ul, "rgba(255,217,61,0.12)", "Caution (90-100% UL)"))
        zones.append((ul, y_top, "rgba(255,107,107,0.15)", "Critical (>=UL)"))
    elif col == "Elongation" and pd.notna(ll):
        zones.append((1.10 * ll, y_top, "rgba(46,160,67,0.08)", "Safe (>110% LL)"))
        zones.append((ll, 1.10 * ll, "rgba(255,217,61,0.12)", "Caution (100-110% LL)"))
        zones.append((y_bot, ll, "rgba(255,107,107,0.15)", "Critical (<=LL)"))
    elif col == "UTS" and pd.notna(ll) and pd.notna(ul):
        band = ul - ll
        if band > 0:
            zones.append((ll + 0.15*band, ul - 0.15*band, "rgba(46,160,67,0.08)", "Safe (Center 70%)"))
            zones.append((ll, ll + 0.15*band, "rgba(255,217,61,0.12)", "Caution (Lower 15%)"))
            zones.append((ul - 0.15*band, ul, "rgba(255,217,61,0.12)", "Caution (Upper 15%)"))
            zones.append((y_bot, ll, "rgba(255,107,107,0.15)", "Critical (<=LL)"))
            zones.append((ul, y_top, "rgba(255,107,107,0.15)", "Critical (>=UL)"))

    for y0, y1, color, label in zones:
        fig.add_hrect(y0=y0, y1=y1, fillcolor=color, line_width=0, annotation_text=label,
                      annotation_font=dict(size=10, color=FONT_CLR, weight="bold"), annotation_position="right")
    return fig

def add_spec_outlier_layer(fig, data, x_col, y_col):
    if not show_outliers: return fig
    mask = spec_outlier_mask(data, y_col)
    out  = data[mask].copy()
    if out.empty: return fig
    ll_col, ul_col = f"{y_col}_LL", f"{y_col}_UL"
    hover_parts = (
        "<b>🔴 CRITICAL OUTLIER</b><br><b>Lot:</b> %{customdata[0]}<br><b>Date:</b> %{customdata[1]}<br>"
        "<b>Material:</b> %{customdata[2]}<br><b>Description:</b> %{customdata[3]}<br>"
        "<b>Supplier:</b> %{customdata[4]}<br>──────────────<br>"
        "<b>Value:</b> %{y:.4f}<br><b>Lower Limit:</b> %{customdata[5]}<br>"
        "<b>Upper Limit:</b> %{customdata[6]}<br><b>Yield Point:</b> %{customdata[7]} MPa<br>"
        "<b>UTS:</b> %{customdata[8]} MPa<br><b>Elongation:</b> %{customdata[9]} %<br>"
        "<b>Carbon %:</b> %{customdata[10]}<br><b>TSYP:</b> %{customdata[11]}<extra></extra>"
    )
    def fmt(v, dec=2): return f"{v:.{dec}f}" if pd.notna(v) else "N/A"
    customdata = np.array([
        [row["Inspection Lot"], row["Inspection Lot Date"].strftime("%d-%b-%Y") if pd.notna(row["Inspection Lot Date"]) else "N/A",
         row["Material Number"], row.get("Material Description","N/A"), row.get("Supplier Name","N/A"),
         fmt(row.get(ll_col,np.nan)), fmt(row.get(ul_col,np.nan)), fmt(row.get("Yield_Point",np.nan),1), fmt(row.get("UTS",np.nan),1),
         fmt(row.get("Elongation",np.nan),2), fmt(row.get("Carbon_pct",np.nan),4), fmt(row.get("TSYP",np.nan),4)]
        for _, row in out.iterrows()
    ], dtype=object)
    fig.add_trace(go.Scatter(x=out[x_col], y=out[y_col], mode="markers",
                             marker=dict(symbol="circle-open", color="#ff6b6b", size=18, line=dict(width=3)),
                             name="Critical Point", customdata=customdata, hovertemplate=hover_parts, showlegend=True))
    return fig

def get_hover_template(x_is_val=False):
    val_str = "<b>Value:</b> %{x:.4f}" if x_is_val else "<b>Value:</b> %{y:.4f}"
    if show_hover:
        return (
            "<b>Lot:</b> %{customdata[0]}<br><b>Date:</b> %{customdata[1]}<br>"
            "<b>Material:</b> %{customdata[2]}<br><b>Description:</b> %{customdata[3]}<br>"
            "<b>Supplier:</b> %{customdata[4]}<br>──────────────<br>"
            f"{val_str}<br><b>Yield Point:</b> %{{customdata[5]}} MPa<br>"
            "<b>UTS:</b> %{customdata[6]} MPa<br><b>Elongation:</b> %{customdata[7]} %<br>"
            "<b>Carbon %:</b> %{customdata[8]}<br><b>TSYP:</b> %{customdata[9]}<br>"
            "<b>Lower Limit:</b> %{customdata[10]}<br><b>Upper Limit:</b> %{customdata[11]}<extra></extra>"
        )
    else:
        return f"<b>Lot:</b> %{{customdata[0]}}<br>{val_str}<extra></extra>" 

def build_customdata(data, ll_col, ul_col):
    def fmt(v, dec=2): return f"{v:.{dec}f}" if pd.notna(v) else "N/A"
    return np.array([
        [row["Inspection Lot"], row["Inspection Lot Date"].strftime("%d-%b-%Y") if pd.notna(row["Inspection Lot Date"]) else "N/A",
         row["Material Number"], row.get("Material Description","N/A"), row.get("Supplier Name","N/A"),
         fmt(row.get("Yield_Point",np.nan),1), fmt(row.get("UTS",np.nan),1), fmt(row.get("Elongation",np.nan),2), 
         fmt(row.get("Carbon_pct",np.nan),4), fmt(row.get("TSYP",np.nan),4), fmt(row.get(ll_col,np.nan)), fmt(row.get(ul_col,np.nan))]
        for _, row in data.iterrows()
    ], dtype=object)

# ── Dynamic Normal Distribution Helper ───────────────────────────────────────────
def normal_distribution_chart(data, col, title_text, x_title):
    d_norm = data.dropna(subset=[col]).copy()
    if len(d_norm) < 3:
        return None, f"Not enough {title_text} data points to plot normal distribution (need ≥ 3)."
    
    mu_all = d_norm[col].mean()
    sig_all = d_norm[col].std()
    
    if sig_all == 0 or np.isnan(sig_all):
         return None, f"Standard deviation is 0 for {title_text}, cannot compute normal distribution."
    
    x_range = np.linspace(mu_all - 4*sig_all, mu_all + 4*sig_all, 400)
    pdf_all = scipy_stats.norm.pdf(x_range, mu_all, sig_all)
    
    fig_norm = go.Figure()
    fig_norm.add_trace(go.Histogram(x=d_norm[col], histnorm="probability density", name=f"{title_text} Observed", marker_color=COLORS[0], opacity=0.35, nbinsx=30, showlegend=True))
    
    ll_col = f"{col}_LL"
    ul_col = f"{col}_UL"
    
    # Scatter points for lots at y=0
    for i, mat in enumerate(d_norm["Material Number"].unique()):
        sub_vals = d_norm[d_norm["Material Number"] == mat]
        clr = COLORS[i % len(COLORS)]
        cd = build_customdata(sub_vals, ll_col, ul_col)
        fig_norm.add_trace(go.Scatter(
            x=sub_vals[col], y=[0]*len(sub_vals), mode="markers",
            name=f"{display_name(mat)} (Lots)",
            marker=dict(color=clr, size=8, opacity=0.8, line=dict(width=1, color=PAPER_BG)),
            customdata=cd, hovertemplate=get_hover_template(x_is_val=True), showlegend=False
        ))
    
    # PDF curve for individual materials
    for i, mat in enumerate(d_norm["Material Number"].unique()):
        sub_vals = d_norm[d_norm["Material Number"] == mat][col].dropna()
        if len(sub_vals) < 3: continue
        mu_m, sig_m = sub_vals.mean(), sub_vals.std()
        if sig_m == 0 or np.isnan(sig_m): continue
        x_m = np.linspace(mu_m - 4*sig_m, mu_m + 4*sig_m, 300)
        clr = COLORS[i % len(COLORS)]
        fig_norm.add_trace(go.Scatter(x=x_m, y=scipy_stats.norm.pdf(x_m, mu_m, sig_m), mode="lines", name=f"{display_name(mat)}  μ={mu_m:.3f}  σ={sig_m:.4f}", line=dict(color=clr, width=2, dash="dot"), opacity=0.90, hovertemplate=f"<b>{display_name(mat)}</b><br>{title_text}: %{{x:.4f}}<br>Density: %{{y:.4f}}<extra></extra>"))
    
    # Overall PDF Curve
    fig_norm.add_trace(go.Scatter(x=x_range, y=pdf_all, mode="lines", name=f"Overall  N(μ={mu_all:.3f}, σ={sig_all:.4f})", line=dict(color=ACCENT, width=3.5), hovertemplate=f"{title_text}: %{{x:.4f}}<br>Density: %{{y:.4f}}<extra></extra>"))
    
    if show_zones:
        for y0, y1, fill, lbl in [(mu_all-3*sig_all, mu_all+3*sig_all, "rgba(255,107,107,0.08)", "99.7%"), (mu_all-2*sig_all, mu_all+2*sig_all, "rgba(249,115,22,0.1)",  "95%"), (mu_all-sig_all,   mu_all+sig_all,   "rgba(255,217,61,0.15)",  "68%")]:
            fig_norm.add_vrect(x0=y0, x1=y1, fillcolor=fill, line_width=0, annotation_text=lbl, annotation_font=dict(size=11, color=FONT_CLR, weight="bold"), annotation_position="top left")
    
    if show_limits:
        for xv, clr, dash, lbl in [(mu_all, ACCENT, "solid", "μ"), (mu_all+sig_all, "#ffd93d", "dash", "+1σ"), (mu_all-sig_all, "#ffd93d", "dash", "−1σ"), (mu_all+2*sig_all, "#f97316", "dot", "+2σ"), (mu_all-2*sig_all, "#f97316", "dot", "−2σ"), (mu_all+3*sig_all, "#ff6b6b", "dashdot", "+3σ"), (mu_all-3*sig_all, "#ff6b6b", "dashdot", "−3σ")]:
            fig_norm.add_vline(x=xv, line_dash=dash, line_color=clr, line_width=1.5, opacity=0.85, annotation_text=lbl, annotation_font=dict(color=clr, size=11, weight="bold"), annotation_position="top")
    
    base_layout(fig_norm)
    fig_norm.update_layout(title=dict(text=f"Normal Distribution | μ = {mu_all:.4f}  σ = {sig_all:.4f}  n = {len(d_norm)}", font=dict(color=H2_CLR, size=13, family="Inter"), x=0.0), xaxis_title=dict(text=x_title, font=dict(color=FONT_CLR)), yaxis_title=dict(text="Probability Density", font=dict(color=FONT_CLR)), margin=dict(l=60, r=40, t=30, b=170))
    
    skew_val = scipy_stats.skew(d_norm[col].dropna())
    kurt_val = scipy_stats.kurtosis(d_norm[col].dropna())
    stats_html = f"<div style='font-size:13px; color:{FONT_CLR}; margin-top:-10px; margin-bottom:12px; background:{CARD_BG}; border: 1px solid {CARD_BR}; padding: 12px; border-radius: 8px; text-align: center'><b style='color:{ACCENT}'>68.27%</b> within μ±1σ &nbsp;&nbsp;|&nbsp;&nbsp;<b style='color:#f97316'>95.45%</b> within μ±2σ &nbsp;&nbsp;|&nbsp;&nbsp;<b style='color:#ff6b6b'>99.73%</b> within μ±3σ&nbsp;&nbsp;—&nbsp;&nbsp;Skewness: <b>{skew_val:.3f}</b> &nbsp;&nbsp;|&nbsp;&nbsp; Kurtosis: <b>{kurt_val:.3f}</b></div>"
    
    return fig_norm, stats_html

def param_chart(data, col, chart_title="", view_type="Trend"):
    d = data.dropna(subset=[col]).copy()
    ll, ul = spec_stats(data, col)
    ll_col, ul_col = f"{col}_LL", f"{col}_UL"
    fig = go.Figure()
    
    if view_type == "Trend":
        for i, mat in enumerate(d["Material Number"].unique()):
            sub = d[d["Material Number"] == mat].copy()
            cd  = build_customdata(sub, ll_col, ul_col)
            clr = COLORS[i % len(COLORS)]
            fig.add_trace(go.Scatter(x=sub["Inspection Lot"], y=sub[col],
                                     mode="lines+markers", name=display_name(mat),
                                     line=dict(color=clr, width=2.5), marker=dict(color=clr, size=6),
                                     customdata=cd, hovertemplate=get_hover_template()))
        add_zone_shading(fig, col, ll, ul, d[col])
        add_spec_lines(fig, ll, ul)
        add_spec_outlier_layer(fig, d, "Inspection Lot", col)
        base_layout(fig)
        fig.update_layout(
            title=dict(text="", font=dict(color=H2_CLR, size=15, family="Inter", weight="bold"), x=0.0, pad=dict(t=10)),
            yaxis_title=dict(text=PARAM_LABELS.get(col, col), font=dict(color=FONT_CLR)), 
            xaxis_title=dict(text="Inspection Lot", font=dict(color=FONT_CLR))
        )
    else: 
        vals_all = d[col].dropna()
        if len(vals_all) > 0:
            counts, bin_edges = np.histogram(vals_all, bins='auto')
            bin_size = bin_edges[1] - bin_edges[0]
            bin_start = bin_edges[0]
            
            for i, mat in enumerate(d["Material Number"].unique()):
                sub = d[d["Material Number"] == mat].copy()
                clr = COLORS[i % len(COLORS)]
                
                fig.add_trace(go.Histogram(
                    x=sub[col], name=display_name(mat), marker_color=clr, opacity=0.85,
                    xbins=dict(start=bin_start, size=bin_size),
                    hovertemplate="<b>Range:</b> %{x}<br><b>Lots Count:</b> %{y}<extra></extra>"
                ))
            
            fig.update_layout(barmode='stack', xaxis=dict(tickmode='array', tickvals=bin_edges, tickformat=".2f"))

        if show_limits:
            if pd.notna(ll) and pd.notna(ul):
                mean = (ll + ul) / 2
                fig.add_vline(x=mean, line_dash="dot", line_color=FONT_CLR, line_width=1.5, opacity=0.7, annotation_text=f"Mean ({mean:.2f})", annotation_position="top")
            if pd.notna(ll):
                fig.add_vline(x=ll, line_dash="dash", line_color="#ff6b6b", line_width=2, annotation_text=f"LL ({ll:.2f})", annotation_position="top left", annotation_font=dict(color="#ff6b6b"))
            if pd.notna(ul):
                fig.add_vline(x=ul, line_dash="dash", line_color="#ff6b6b", line_width=2, annotation_text=f"UL ({ul:.2f})", annotation_position="top right", annotation_font=dict(color="#ff6b6b"))
                
        base_layout(fig)
        fig.update_layout(
            title=dict(text="", font=dict(color=H2_CLR, size=15, family="Inter", weight="bold"), x=0.0, pad=dict(t=10)),
            xaxis_title=dict(text=PARAM_LABELS.get(col, col), font=dict(color=FONT_CLR)), 
            yaxis_title=dict(text="Number of Lots", font=dict(color=FONT_CLR))
        )

    return fig

def build_alerts(data):
    alerts = []
    for _, row in data.iterrows():
        lot = row["Inspection Lot"] 
        sup = row.get("Supplier Name", "Unknown Supplier")
        mat = row["Material Number"]
        desc = row.get("Material Description", "")
        
        for col in ["Yield_Point", "Carbon_pct"]:
            val = row.get(col)
            ul  = row.get(f"{col}_UL")
            if pd.notna(val) and pd.notna(ul):
                if val >= ul:
                    alerts.append(("critical", PARAM_LABELS.get(col,col), mat, desc, val, ul, ">= Upper Limit", lot, sup))
                elif val >= 0.90 * ul:
                    alerts.append(("warn", PARAM_LABELS.get(col,col), mat, desc, val, ul, "Within 10% of Upper Limit", lot, sup))
                    
        col_el = "Elongation"
        val_el = row.get(col_el)
        ll_el  = row.get(f"{col_el}_LL")
        if pd.notna(val_el) and pd.notna(ll_el):
            if val_el <= ll_el:
                alerts.append(("critical", PARAM_LABELS.get(col_el,col_el), mat, desc, val_el, ll_el, "<= Lower Limit", lot, sup))
            elif val_el <= 1.10 * ll_el:
                alerts.append(("warn", PARAM_LABELS.get(col_el,col_el), mat, desc, val_el, ll_el, "Within 10% of Lower Limit", lot, sup))
                
        col_uts = "UTS"
        val_uts = row.get(col_uts)
        ll_uts  = row.get(f"{col_uts}_LL")
        ul_uts  = row.get(f"{col_uts}_UL")
        if pd.notna(val_uts) and pd.notna(ll_uts) and pd.notna(ul_uts):
            band = ul_uts - ll_uts
            if val_uts <= ll_uts:
                alerts.append(("critical", PARAM_LABELS.get(col_uts,col_uts), mat, desc, val_uts, ll_uts, "<= Lower Limit", lot, sup))
            elif val_uts >= ul_uts:
                alerts.append(("critical", PARAM_LABELS.get(col_uts,col_uts), mat, desc, val_uts, ul_uts, ">= Upper Limit", lot, sup))
            elif val_uts < ll_uts + 0.15 * band or val_uts > ul_uts - 0.15 * band:
                alerts.append(("warn", PARAM_LABELS.get(col_uts,col_uts), mat, desc, val_uts, ul_uts if val_uts > (ll_uts+ul_uts)/2 else ll_uts, "Outer 15% of Tolerance Band", lot, sup))

        col_tsyp = "TSYP"
        val_tsyp = row.get(col_tsyp)
        if pd.notna(val_tsyp):
            if val_tsyp < 1.15:
                alerts.append(("critical", "TSYP Ratio", mat, desc, val_tsyp, 1.15, "< 1.15", lot, sup))
            elif val_tsyp <= 1.20:
                alerts.append(("warn", "TSYP Ratio", mat, desc, val_tsyp, 1.20, "1.15 - 1.20", lot, sup))

    return alerts

def generate_oos_mask(df_subset):
    mask = pd.Series(False, index=df_subset.index)
    if "Yield_Point_UL" in df_subset.columns: mask |= df_subset["Yield_Point"].notna() & df_subset["Yield_Point_UL"].notna() & (df_subset["Yield_Point"] >= df_subset["Yield_Point_UL"])
    if "Carbon_pct_UL" in df_subset.columns: mask |= df_subset["Carbon_pct"].notna() & df_subset["Carbon_pct_UL"].notna() & (df_subset["Carbon_pct"] >= df_subset["Carbon_pct_UL"])
    if "Elongation_LL" in df_subset.columns: mask |= df_subset["Elongation"].notna() & df_subset["Elongation_LL"].notna() & (df_subset["Elongation"] <= df_subset["Elongation_LL"])
    if "UTS_LL" in df_subset.columns and "UTS_UL" in df_subset.columns: mask |= df_subset["UTS"].notna() & df_subset["UTS_LL"].notna() & df_subset["UTS_UL"].notna() & ((df_subset["UTS"] <= df_subset["UTS_LL"]) | (df_subset["UTS"] >= df_subset["UTS_UL"]))
    if "TSYP" in df_subset.columns: mask |= df_subset["TSYP"].notna() & (df_subset["TSYP"] < 1.15)
    return mask

# ═════════════════════════ PAGE LAYOUT ════════════════════════════════════════

if st.session_state.show_right_panel:
    main_col, monitor_col = st.columns([3.2, 1.1], gap="large")
else:
    main_col = st.container()
    monitor_col = None

# ── RIGHT MONITOR PANEL ────────────────────────────────────────────────────────
if monitor_col:
    with monitor_col:
        st.markdown(f"<div class='monitor-header' style='border:none; margin-bottom:8px;'>Daily Intake Monitor</div>", unsafe_allow_html=True)
        
        monitor_date = st.date_input("📅 Operations Date",
            value=df["Inspection Lot Date"].max().date(),
            min_value=df["Inspection Lot Date"].min().date(),
            max_value=df["Inspection Lot Date"].max().date(),
            key="monitor_date_picker",
            help="Independent date selector")

        monitor_ts = pd.Timestamp(monitor_date)
        day_df = df[df["Inspection Lot Date"] == monitor_ts].copy()
        n_lots_today = day_df["Inspection Lot"].nunique()
        n_mats_today = day_df["Material Number"].nunique()
        n_sup_today  = day_df["Supplier Name"].nunique()

        day_oos_mask = generate_oos_mask(day_df)
        day_oos_count = int(day_oos_mask.sum())
        
        day_alerts = build_alerts(day_df)
        day_critical = [a for a in day_alerts if a[0] == "critical"]
        day_warnings = [a for a in day_alerts if a[0] == "warn"]

        html_parts = []
        html_parts.append(f"<div class='monitor-panel' style='margin-top: 12px;'>")
        html_parts.append(f"<div class='monitor-big'>{n_lots_today}</div>")
        html_parts.append(f"<div class='monitor-sub'>Lots Received</div>")
        
        html_parts.append(f"<div style='display: flex; gap: 8px; margin-bottom: 16px;'>")
        html_parts.append(f"<div class='metric-card' style='padding:12px 6px; border-color: {MON_CHIP_BR}; flex: 1;'>")
        html_parts.append(f"<div class='metric-label' style='font-size:9px; margin-bottom: 4px;'>Materials</div>")
        html_parts.append(f"<div class='metric-value' style='font-size:20px; margin: 0;'>{n_mats_today}</div>")
        html_parts.append(f"</div>")
        html_parts.append(f"<div class='metric-card' style='padding:12px 6px; border-color: {MON_CHIP_BR}; flex: 1;'>")
        html_parts.append(f"<div class='metric-label' style='font-size:9px; margin-bottom: 4px;'>Suppliers</div>")
        html_parts.append(f"<div class='metric-value' style='font-size:20px; margin: 0;'>{n_sup_today}</div>")
        html_parts.append(f"</div>")
        
        if show_alerts:
            oos_val_clr = ALERT_TT if day_oos_count > 0 else CARD_VAL
            oos_bg_clr = ALERT_BG if day_oos_count > 0 else CARD_BG
            oos_br_clr = ALERT_TT if day_oos_count > 0 else MON_CHIP_BR
            html_parts.append(f"<div class='metric-card' style='padding:12px 6px; border-color: {oos_br_clr}; background: {oos_bg_clr}; flex: 1;'>")
            html_parts.append(f"<div class='metric-label' style='font-size:9px; margin-bottom: 4px;'>OOS Lots</div>")
            html_parts.append(f"<div class='metric-value' style='font-size:20px; margin: 0; color: {oos_val_clr}'>{day_oos_count}</div>")
            html_parts.append(f"</div>")
            
        html_parts.append(f"</div>")

        if show_alerts and (day_critical or day_warnings):
            banner_bg = ALERT_BG if day_critical else ALERT_W_BG
            banner_br = ALERT_BL if day_critical else ALERT_W_BL
            banner_tt = ALERT_TT if day_critical else ALERT_W_TT
            html_parts.append(f"<div style='background: {banner_bg}; border: 1px solid {banner_tt}55; border-left: {banner_br}; border-radius: 6px; padding: 10px 12px; margin-bottom: 20px; text-align: center;'>")
            html_parts.append(f"<div style='color: {banner_tt}; font-size: 11px; font-weight: 800; letter-spacing: 0.05em; text-transform: uppercase;'>")
            html_parts.append(f"⚠️ Action Required<br><span style='font-size: 13px;'>{len(day_critical)} Critical · {len(day_warnings)} Caution</span>")
            html_parts.append(f"</div></div>")

        if day_df.empty:
            html_parts.append(f"<div class='empty-monitor'>No intake data for this date</div>")
            html_parts.append(f"</div>")
            st.markdown("".join(html_parts), unsafe_allow_html=True)
        else:
            html_parts.append(f"<div class='monitor-section'>🏭 Supplier Intake</div>")
            for sup in day_df["Supplier Name"].dropna().unique():
                sup_lots  = day_df[day_df["Supplier Name"] == sup]["Inspection Lot"].nunique()
                sup_crits = len([a for a in day_critical if a[8] == sup])
                sup_warns = len([a for a in day_warnings if a[8] == sup])
                
                badges = ""
                if sup_crits > 0 and show_alerts:
                    badges += f"<span style='background:{ALERT_BG}; color:{ALERT_TT}; border: 1px solid {ALERT_TT}55; padding:2px 6px; border-radius:4px; font-size:9px; margin-right:4px;'><b>{sup_crits}</b> CRIT</span>"
                if sup_warns > 0 and show_alerts:
                    badges += f"<span style='background:{ALERT_W_BG}; color:{ALERT_W_TT}; border: 1px solid {ALERT_W_TT}55; padding:2px 6px; border-radius:4px; font-size:9px;'><b>{sup_warns}</b> CAUT</span>"
                if not badges:
                    badges = f"<span style='background:#38a16915; color:#38a169; border: 1px solid #38a16955; padding:2px 6px; border-radius:4px; font-size:9px;'>SAFE</span>"

                html_parts.append(f"<div class='monitor-supplier-chip' title='{sup}'>"
                                  f"<div style='display:flex; justify-content:space-between; align-items:center;'>"
                                  f"<b><span class='truncate' style='max-width: 140px;'>{sup}</span></b>"
                                  f"<span style='font-size:10px; opacity:0.8;'>{sup_lots} lot(s)</span>"
                                  f"</div>"
                                  f"<div style='margin-top:6px;'>{badges}</div>"
                                  f"</div>")
                            
            html_parts.append(f"</div>")
            st.markdown("".join(html_parts), unsafe_allow_html=True)
            
            # ---------------------------------------------------------
            # TOGGLE LOGIC FOR MATERIALS PROCESSED
            # ---------------------------------------------------------
            st.markdown(f"<div class='monitor-section' style='margin-top:0px; margin-bottom:8px'>📦 Materials Processed</div>", unsafe_allow_html=True)
            
            mat_info_list = []
            for _, mrow in (day_df[["Material Number","Material Description"]].drop_duplicates()).iterrows():
                mat_id = mrow["Material Number"]
                mat_desc = mrow["Material Description"]
                mat_df = day_df[day_df["Material Number"] == mat_id]
                lots_for_mat = mat_df["Inspection Lot"].nunique()
                suppliers = mat_df["Supplier Name"].dropna().unique()
                sup_str = " / ".join(suppliers) if len(suppliers) > 0 else "Unknown Supplier"
                mat_crits = len([a for a in day_critical if a[2] == mat_id])
                mat_warns = len([a for a in day_warnings if a[2] == mat_id])
                
                mat_info_list.append({
                    "id": mat_id, "desc": mat_desc, "lots": lots_for_mat,
                    "sup_str": sup_str, "crits": mat_crits, "warns": mat_warns
                })
            
            mat_info_list.sort(key=lambda x: (x["crits"] > 0, x["warns"] > 0), reverse=True)
            
            if mat_info_list:
                show_all_mats = st.toggle("View material details list", value=False)
                
                if show_all_mats:
                    chip_html = ""
                    for minfo in mat_info_list:
                        if minfo["crits"] > 0 and show_alerts:
                            m_bg = ALERT_BG; m_br = ALERT_TT
                        elif minfo["warns"] > 0 and show_alerts:
                            m_bg = ALERT_W_BG; m_br = ALERT_W_TT
                        else:
                            m_bg = MON_CHIP_BG; m_br = "#38a169" 
                            
                        chip_html += (f"<div class='monitor-chip' style='background:{m_bg}; border-color:{m_br}; transition: transform 0.2s ease;' title='{minfo['desc']} | {minfo['sup_str']}'>"
                                    f"<div><span class='monitor-chip-id'>{minfo['id']}</span>"
                                    f"<span style='float: right; color:{m_br}; font-size:11px; font-weight:800'>{minfo['lots']} Lots</span></div>"
                                    f"<div class='monitor-chip-desc truncate'>{minfo['desc']}</div>"
                                    f"<div class='truncate' style='font-size: 9px; opacity: 0.75; margin-top: 4px; font-weight: 600; text-transform: uppercase;'>🏭 {minfo['sup_str']}</div>"
                                    f"</div>")
                    st.markdown(chip_html, unsafe_allow_html=True)

# ── MAIN CONTENT ───────────────────────────────────────────────────────────────
with main_col:
    n_lots = filtered["Inspection Lot"].nunique()
    n_mats = filtered["Material Number"].nunique()
    
    title_col, toggle_col = st.columns([5, 1])
    with toggle_col:
        st.markdown("<br>", unsafe_allow_html=True)
        btn_label = "➡️ Close Monitor" if st.session_state.show_right_panel else "⬅️ Open Daily Monitor"
        if st.button(btn_label, use_container_width=True):
            st.session_state.show_right_panel = not st.session_state.show_right_panel
            st.rerun()

    st.markdown(f"""
    <div style='padding-bottom: 1.5rem; margin-bottom: 2rem; border-bottom: 1px solid {HR_CLR}; margin-top: -20px;'>
        <h1 style='color:{H1_CLR}; margin:0; font-weight:800; font-size:2.4rem; letter-spacing:-0.02em;'>🏭 Material Inspection Dashboard Press Shop</h1>
        <div style='display:flex; align-items:center; gap: 12px; margin-top: 12px; flex-wrap: wrap;'>
            <span style='color:{H2_CLR}; font-weight:600; font-size:1.1rem;'>Maruti Suzuki — IoT SPACE Quality Analytics</span>
            <span style='color:{HR_CLR}'>|</span>
            <span style='background:{CARD_BG}; border:1px solid {CARD_BR}; padding: 4px 10px; border-radius: 6px; font-size: 13px; font-weight:600; color:{H2_CLR}'>{n_lots} Lots</span>
            <span style='background:{CARD_BG}; border:1px solid {CARD_BR}; padding: 4px 10px; border-radius: 6px; font-size: 13px; font-weight:600; color:{H2_CLR}'>{n_mats} Materials</span>
            <span style='background:{CARD_BG}; border:1px solid {CARD_BR}; padding: 4px 10px; border-radius: 6px; font-size: 13px; font-weight:600; color:{H2_CLR}'>📅 {s_date.date()} → {e_date.date()}</span>
        </div>
    </div>
    """, unsafe_allow_html=True)

    available_graphs = [
        "Yield Point", "Yield Point Normal Dist",
        "Ultimate Tensile Strength", "UTS Normal Dist",
        "Elongation", 
        "Carbon %", "Carbon % Normal Dist",
        "TSYP Trend", "TSYP Bar Charts", "TSYP Distribution", 
        "Yield Point vs UTS", "Yield Point & UTS by Supplier"
    ]
    selected_graphs = st.multiselect("Select Graphs to Display", options=available_graphs, default=[
        "Yield Point", "Ultimate Tensile Strength", "Elongation", "Carbon %", 
        "TSYP Trend", "TSYP Bar Charts", "TSYP Distribution", 
        "Yield Point vs UTS", "Yield Point & UTS by Supplier"
    ])
    st.markdown("---")

    # ── KPI Cards ───────────────────────────
    avg_tsyp  = filtered["TSYP"].mean()
    std_tsyp  = filtered["TSYP"].std()
    avg_yp    = filtered["Yield_Point"].mean()
    avg_uts   = filtered["UTS"].mean()
    avg_elong = filtered["Elongation"].mean()
    avg_carbon= filtered["Carbon_pct"].mean()

    if "Inspection Lot Qty" in filtered.columns:
        avg_wt_kg = filtered["Inspection Lot Qty"].mean()
        avg_wt_tons = avg_wt_kg / 1000 if pd.notna(avg_wt_kg) else np.nan
        wt_str = f"{avg_wt_tons:,.2f}" if pd.notna(avg_wt_tons) else "N/A"
    else:
        wt_str = "N/A"

    overall_oos_mask = generate_oos_mask(filtered)
    oos_count = int(overall_oos_mask.sum())

    kpi_map = [
        ("Avg Weight", wt_str, "Tons", False), 
        ("Avg TSYP", f"{avg_tsyp:.4f}", "UTS / Yield Point", False),
        ("Std Dev TSYP", f"{std_tsyp:.4f}", "Variability", False),
        ("Avg Yield Point", f"{avg_yp:.1f}", "MPa", False),
        ("Avg UTS", f"{avg_uts:.1f}", "MPa", False),
        ("Avg Elongation", f"{avg_elong:.2f}", "%", False),
        ("Avg Carbon %", f"{avg_carbon:.4f}", "% Carbon", False)
    ]
    
    if show_alerts:
        kpi_map.append(("Out-of-Spec Lots", str(oos_count), "🔴 Critical Exception Found" if oos_count > 0 else "✅ 100% in spec", oos_count > 0))

    kpi_html = "<div class='kpi-container'>"
    for label, value, sub_lbl, red in kpi_map:
        vc = "#ff6b6b" if red else CARD_VAL
        bc = "#ff6b6b55" if red else CARD_BR
        bg = ALERT_BG if red else CARD_BG
        kpi_html += f"""
        <div class='kpi-wrapper'>
            <div class='metric-card' style='border-color:{bc}; background:{bg}'>
                <div class='metric-label'>{label}</div>
                <div class='metric-value' style='color:{vc}'>{value}</div>
                <div class='metric-sub'>{sub_lbl}</div>
            </div>
        </div>"""
    kpi_html += "</div>"
    
    st.markdown(kpi_html, unsafe_allow_html=True)
    st.markdown("<br>", unsafe_allow_html=True)

    # ── Alerts ───────────────────────────
    alerts   = build_alerts(filtered)
    critical = [a for a in alerts if a[0] == "critical"]
    warnings = [a for a in alerts if a[0] == "warn"]

    if show_alerts and (critical or warnings):
        with st.expander(f"⚠️ Action Required — {len(critical)} Critical · {len(warnings)} Caution", expanded=(len(critical) > 0)):
            st.markdown("<br>", unsafe_allow_html=True)
            ac1, ac2 = st.columns(2, gap="large")
            with ac1:
                st.markdown(f"<h4 style='color:{ALERT_TT}; margin-bottom:16px;'>🔴 Critical Exceptions ({len(critical)})</h4>", unsafe_allow_html=True)
                if critical:
                    seen = set()
                    for sev,param,mat,desc,val,lim,dir_,lot,sup in critical[:20]:
                        key = (param,mat,lot,dir_) 
                        if key in seen: continue
                        seen.add(key)
                        
                        st.markdown(f"""<div class='alert-card'>
                            <div class='alert-title'>
                                🔴 {param} 
                                <span style='float:right; font-size:10px; opacity:0.8; font-weight:600; color:{FONT_CLR}'>
                                    LOT: {lot} <br>
                                    <span style='color:{ALERT_TT}'>SUP: {sup}</span>
                                </span>
                            </div>
                            <div class='alert-body'>
                                <span style='font-family:monospace; font-weight:800; color:{H1_CLR}'>{mat}</span> 
                                <span class='truncate' style='opacity:0.8; font-size:12px; margin-bottom:6px' title='{desc}'>{desc}</span>
                                Recorded: <b style='color:{ALERT_TT}; font-size: 16px'>{val:.3f}</b> <br>
                                <span style='opacity:0.8; font-size: 12px'>Breach: {dir_} (Limit: {lim:.3f})</span>
                            </div>
                        </div>""", unsafe_allow_html=True)
                else:
                    st.success("No critical readings detected.")
            with ac2:
                st.markdown(f"<h4 style='color:{ALERT_W_TT}; margin-bottom:16px;'>🟡 Caution Zone ({len(warnings)})</h4>", unsafe_allow_html=True)
                if warnings:
                    seen_w = set()
                    for sev,param,mat,desc,val,lim,dir_,lot,sup in warnings[:20]:
                        key = (param,mat,lot)
                        if key in seen_w: continue
                        seen_w.add(key)
                        
                        st.markdown(f"""<div class='alert-card-warn'>
                            <div class='alert-title-warn'>
                                🟡 {param} 
                                <span style='float:right; font-size:10px; opacity:0.8; font-weight:600; color:{FONT_CLR}'>
                                    LOT: {lot} <br>
                                    <span style='color:{ALERT_W_TT}'>SUP: {sup}</span>
                                </span>
                            </div>
                            <div class='alert-body'>
                                <span style='font-family:monospace; font-weight:800; color:{H1_CLR}'>{mat}</span> 
                                <span class='truncate' style='opacity:0.8; font-size:12px; margin-bottom:6px' title='{desc}'>{desc}</span>
                                Recorded: <b style='color:{ALERT_W_TT}; font-size: 16px'>{val:.3f}</b> <br>
                                <span style='opacity:0.8; font-size: 12px'>{dir_}</span>
                            </div>
                        </div>""", unsafe_allow_html=True)

    st.markdown("---")
    
    # ── Presentation View (Slide Format) ──────────────────────────────────
    def render_graph(g_name, container_context=st):
        tooltip = TOOLTIPS.get(g_name, "")
        if tooltip:
            container_context.markdown(
                f"<div class='section-title' style='margin-bottom: 5px; font-size: 18px; text-transform: none;'>"
                f"{g_name} <span title='{tooltip}' style='cursor:help; font-size:16px;'>ℹ️</span></div>", 
                unsafe_allow_html=True)
            
        if g_name == "Yield Point":
            yp_view = container_context.radio("Yield Point View", ["Trend", "Distribution"], horizontal=True, key=f"yp_view_{st.session_state.slide_index}")
            container_context.plotly_chart(param_chart(filtered, "Yield_Point", "Yield Point", yp_view), use_container_width=True)
            
        elif g_name == "Yield Point Normal Dist":
            fig_norm, stats_html = normal_distribution_chart(filtered, "Yield_Point", "Yield Point", "Yield Point (MPa)")
            if fig_norm:
                container_context.plotly_chart(fig_norm, use_container_width=True)
                container_context.markdown(stats_html, unsafe_allow_html=True)
            else:
                container_context.info(stats_html)
                
        elif g_name == "Ultimate Tensile Strength":
            uts_view = container_context.radio("UTS View", ["Trend", "Distribution"], horizontal=True, key=f"uts_view_{st.session_state.slide_index}")
            container_context.plotly_chart(param_chart(filtered, "UTS", "Ultimate Tensile Strength", uts_view), use_container_width=True)
            
        elif g_name == "UTS Normal Dist":
            fig_norm, stats_html = normal_distribution_chart(filtered, "UTS", "Ultimate Tensile Strength", "UTS (MPa)")
            if fig_norm:
                container_context.plotly_chart(fig_norm, use_container_width=True)
                container_context.markdown(stats_html, unsafe_allow_html=True)
            else:
                container_context.info(stats_html)
                
        elif g_name == "Elongation":
            elong_view = container_context.radio("Elongation View", ["Trend", "Distribution"], horizontal=True, key=f"elong_view_{st.session_state.slide_index}")
            container_context.plotly_chart(param_chart(filtered, "Elongation", "Elongation", elong_view), use_container_width=True)
            
        elif g_name == "Carbon %":
            carbon_view = container_context.radio("Carbon % View", ["Trend", "Distribution"], horizontal=True, key=f"carbon_view_{st.session_state.slide_index}")
            container_context.plotly_chart(param_chart(filtered, "Carbon_pct", "Carbon %", carbon_view), use_container_width=True)
            
        elif g_name == "Carbon % Normal Dist":
            fig_norm, stats_html = normal_distribution_chart(filtered, "Carbon_pct", "Carbon %", "Carbon %")
            if fig_norm:
                container_context.plotly_chart(fig_norm, use_container_width=True)
                container_context.markdown(stats_html, unsafe_allow_html=True)
            else:
                container_context.info(stats_html)
                
        elif g_name == "TSYP Trend":
            d_tsyp = filtered.dropna(subset=["TSYP"]).copy()
            fig = go.Figure()
            for i, mat in enumerate(d_tsyp["Material Number"].unique()):
                sub = d_tsyp[d_tsyp["Material Number"] == mat].copy()
                clr = COLORS[i % len(COLORS)]
                fig.add_trace(go.Scatter(x=sub["Inspection Lot"], y=sub["TSYP"], mode="lines+markers", name=display_name(mat), line=dict(color=clr, width=2.5), marker=dict(color=clr, size=6), customdata=build_customdata(sub,"Yield_Point_LL","Yield_Point_UL"), hovertemplate=get_hover_template()))
            if show_limits:
                fig.add_hline(y=1.0, line_dash="dot", line_color=FONT_CLR, line_width=1.5, opacity=0.8, annotation_text="— Minimum TSYP Ratio = 1.0", annotation_font=dict(color=FONT_CLR, size=11, weight="bold"), annotation_position="top left")
            
            if show_zones:
                d_min = d_tsyp["TSYP"].min() if not d_tsyp.empty else 1.0
                d_max = d_tsyp["TSYP"].max() if not d_tsyp.empty else 1.5
                pad = (d_max - d_min) * 0.2 if d_max != d_min else 0.1
                y_top = max(d_max + pad, 1.30)
                y_bot = min(max(0, d_min - pad), 1.10)
                
                fig.add_hrect(y0=1.20, y1=y_top, fillcolor="rgba(46,160,67,0.08)", line_width=0, annotation_text="Safe (>1.20)", annotation_font=dict(size=10, color=FONT_CLR, weight="bold"), annotation_position="right")
                fig.add_hrect(y0=1.15, y1=1.20, fillcolor="rgba(255,217,61,0.12)", line_width=0, annotation_text="Caution (1.15-1.20)", annotation_font=dict(size=10, color=FONT_CLR, weight="bold"), annotation_position="right")
                fig.add_hrect(y0=y_bot, y1=1.15, fillcolor="rgba(255,107,107,0.15)", line_width=0, annotation_text="Critical (<1.15)", annotation_font=dict(size=10, color=FONT_CLR, weight="bold"), annotation_position="right")
                
            base_layout(fig)
            fig.update_layout(title=dict(text="", font=dict(color=H2_CLR, size=15, family="Inter", weight="bold"), x=0.0), yaxis_title=dict(text="TSYP (UTS/YP)", font=dict(color=FONT_CLR)), xaxis_title=dict(text="Inspection Lot", font=dict(color=FONT_CLR)))
            container_context.plotly_chart(fig, use_container_width=True)
            
        elif g_name == "TSYP Bar Charts":
            bc1, bc2 = container_context.columns(2, gap="large")
            with bc1:
                tsyp_by_mat = (filtered.dropna(subset=["TSYP"]).groupby("Material Number")["TSYP"].mean().reset_index().sort_values("TSYP", ascending=True))
                tsyp_by_mat["Display"] = tsyp_by_mat["Material Number"].map(lambda x: (display_name(x)[:20]+"..") if len(display_name(x))>20 else display_name(x))
                fig1 = px.bar(tsyp_by_mat, x="TSYP", y="Display", orientation="h", color="TSYP", color_continuous_scale="Teal", text=tsyp_by_mat["TSYP"].map(lambda x: f"{x:.3f}"), labels={"TSYP":"Avg TSYP","Display":""})
                fig1.update_traces(textposition="outside", textfont_size=11, textfont_color=FONT_CLR, marker_line_width=0)
                base_layout(fig1)
                fig1.update_layout(coloraxis_showscale=False, yaxis=dict(tickfont=dict(size=11, color=FONT_CLR)), title=dict(text="Avg TSYP by Material", font=dict(color=H2_CLR, size=14, family="Inter", weight="bold"), x=0.0))
                st.plotly_chart(fig1, use_container_width=True)
            with bc2:
                std_by_mat = (filtered.dropna(subset=["TSYP"]).groupby("Material Number")["TSYP"].std().reset_index().rename(columns={"TSYP":"Std_TSYP"}).sort_values("Std_TSYP", ascending=True))
                std_by_mat["Display"] = std_by_mat["Material Number"].map(lambda x: (display_name(x)[:20]+"..") if len(display_name(x))>20 else display_name(x))
                fig2 = px.bar(std_by_mat, x="Std_TSYP", y="Display", orientation="h", color="Std_TSYP", color_continuous_scale="OrRd", text=std_by_mat["Std_TSYP"].map(lambda x: f"{x:.4f}" if pd.notna(x) else ""), labels={"Std_TSYP":"Std Dev TSYP","Display":""})
                fig2.update_traces(textposition="outside", textfont_size=11, textfont_color=FONT_CLR, marker_line_width=0)
                base_layout(fig2)
                fig2.update_layout(coloraxis_showscale=False, yaxis=dict(tickfont=dict(size=11, color=FONT_CLR)), title=dict(text="Std Dev TSYP by Material", font=dict(color=H2_CLR, size=14, family="Inter", weight="bold"), x=0.0))
                st.plotly_chart(fig2, use_container_width=True)
                
        elif g_name == "TSYP Distribution":
            fig_norm, stats_html = normal_distribution_chart(filtered, "TSYP", "TSYP", "TSYP (UTS / Yield Point)")
            if fig_norm:
                container_context.plotly_chart(fig_norm, use_container_width=True)
                container_context.markdown(stats_html, unsafe_allow_html=True)
            else:
                container_context.info(stats_html)
                
        elif g_name == "Yield Point vs UTS":
            d_sc = filtered.dropna(subset=["Yield_Point","UTS"]).copy()
            ll_yp, ul_yp = spec_stats(filtered, "Yield_Point")
            ll_uts2, ul_uts2   = spec_stats(filtered, "UTS")
            fig = go.Figure()
            for i, mat in enumerate(d_sc["Material Number"].unique()):
                sub = d_sc[d_sc["Material Number"] == mat].copy()
                clr = COLORS[i % len(COLORS)]
                fig.add_trace(go.Scatter(x=sub["Yield_Point"], y=sub["UTS"], mode="markers", name=display_name(mat), marker=dict(color=clr, size=8, opacity=0.85, line=dict(width=1, color=PAPER_BG)), customdata=build_customdata(sub,"Yield_Point_LL","Yield_Point_UL"), hovertemplate=get_hover_template()))
            x_rng = [d_sc["Yield_Point"].min(), d_sc["Yield_Point"].max()]
            fig.add_trace(go.Scatter(x=x_rng, y=x_rng, mode="lines+text", name="TSYP = 1.0", text=["","TSYP = 1.0 (UTS = YP)"], textposition="top left", textfont=dict(color=FONT_CLR, size=11, weight="bold"), line=dict(dash="dot", color=FONT_CLR, width=1.5), opacity=0.7))
            if show_limits:
                for xv, clr, txt in [(ll_yp, "#ff6b6b", f"◀ YP LL ({ll_yp:.0f})"), (ul_yp, "#ff6b6b", f"▶ YP UL ({ul_yp:.0f})")]:
                    if pd.notna(xv): fig.add_vline(x=xv, line_dash="dash", line_color=clr, line_width=1.5, annotation_text=txt, annotation_font=dict(color=clr,size=11, weight="bold"), annotation_position="top right")
                if pd.notna(ll_yp) and pd.notna(ul_yp):
                    mean_yp = (ll_yp + ul_yp)/2
                    fig.add_vline(x=mean_yp, line_dash="dot", line_color=FONT_CLR, line_width=1.5, opacity=0.7)
                if pd.notna(ll_uts2):
                    fig.add_hline(y=ll_uts2, line_dash="dash", line_color="#ff6b6b", line_width=1.5, annotation_text=f"▼ UTS LL ({ll_uts2:.0f})", annotation_font=dict(color="#ff6b6b",size=11, weight="bold"), annotation_position="bottom right")
            base_layout(fig)
            fig.update_layout(xaxis_title=dict(text="Yield Point (MPa)", font=dict(color=FONT_CLR)), yaxis_title=dict(text="UTS (MPa)", font=dict(color=FONT_CLR)), title=dict(text="", font=dict(color=H2_CLR, size=15, family="Inter", weight="bold"), x=0.0))
            container_context.plotly_chart(fig, use_container_width=True)
            
        elif g_name == "Yield Point & UTS by Supplier":
            sup_agg = (filtered.groupby("Supplier Name").agg(Avg_YP=("Yield_Point","mean"), Avg_UTS=("UTS","mean"), Avg_Elong=("Elongation","mean"), Lots=("Inspection Lot","nunique")).reset_index().sort_values("Avg_YP", ascending=True))
            sup_agg["Supplier Name"] = sup_agg["Supplier Name"].map(lambda x: (x[:25]+"..") if len(x)>25 else x)
            fig = go.Figure()
            fig.add_trace(go.Bar(y=sup_agg["Supplier Name"], x=sup_agg["Avg_YP"], name="Avg Yield Point", orientation="h", marker_color=COLORS[0], opacity=0.9, text=sup_agg["Avg_YP"].map(lambda x: f"{x:.0f}"), textposition="outside", textfont=dict(size=11, color=FONT_CLR)))
            fig.add_trace(go.Bar(y=sup_agg["Supplier Name"], x=sup_agg["Avg_UTS"], name="Avg UTS", orientation="h", marker_color=COLORS[4], opacity=0.9, text=sup_agg["Avg_UTS"].map(lambda x: f"{x:.0f}"), textposition="outside", textfont=dict(size=11, color=FONT_CLR)))
            base_layout(fig)
            fig.update_layout(barmode="group", yaxis=dict(tickfont=dict(size=11, color=FONT_CLR)), title=dict(text="", font=dict(color=H2_CLR, size=15, family="Inter", weight="bold"), x=0.0), xaxis_title=dict(text="MPa", font=dict(color=FONT_CLR)))
            container_context.plotly_chart(fig, use_container_width=True)

    st.markdown("---")
    
    if not selected_graphs:
        st.info("Please select graphs from the filter above.")
    else:
        chunks = selected_graphs
        
        if st.session_state.slide_index >= len(chunks):
            st.session_state.slide_index = max(0, len(chunks) - 1)
            
        slide_options = [f"Slide {i+1} ({c})" for i, c in enumerate(chunks)]
        
        nav_col1, nav_col2, nav_col3, nav_col4 = st.columns([1, 4, 1, 1.5])
        with nav_col1:
            if st.button("⬅️ Previous Slide", use_container_width=True, disabled=(st.session_state.slide_index == 0)):
                st.session_state.slide_index -= 1
                st.rerun()
        with nav_col2:
            chosen = st.selectbox("Jump to Slide", options=range(len(slide_options)), format_func=lambda x: slide_options[x], index=st.session_state.slide_index, label_visibility="collapsed")
            if chosen != st.session_state.slide_index:
                st.session_state.slide_index = chosen
                st.rerun()
        with nav_col3:
            if st.button("Next Slide ➡️", use_container_width=True, disabled=(st.session_state.slide_index == len(chunks) - 1)):
                st.session_state.slide_index += 1
                st.rerun()
        with nav_col4:
            # Adjust padding slightly so the toggle aligns well with buttons
            st.markdown("<div style='padding-top: 5px'>", unsafe_allow_html=True)
            auto_slide = st.toggle("▶️ Auto Slide (5s)", value=False)
            st.markdown("</div>", unsafe_allow_html=True)
                
        st.markdown("<br>", unsafe_allow_html=True)
        
        current_graph = chunks[st.session_state.slide_index]
        
        # Render the current visual
        render_graph(current_graph, st)
        
        # Handle the automatic advancement script logic AFTER rendering the graph
        if auto_slide:
            time.sleep(5)
            st.session_state.slide_index = (st.session_state.slide_index + 1) % len(chunks)
            st.rerun()

st.markdown("---")
with st.expander("🗂️ View Filtered Data Table"):
    show_df_cols = [
        "Inspection Lot","Inspection Lot Date","Material Number",
        "Material Description","Supplier Name", "Inspection Lot Qty",
        "Yield_Point","UTS","Elongation","Carbon_pct","TSYP"
    ]
    
    show_df_cols = [c for c in show_df_cols if c in filtered.columns]
    
    show_df = filtered[show_df_cols].rename(columns={
        "Inspection Lot Qty": "Qty (kg)",
        "Yield_Point":"Yield Point (MPa)",
        "Carbon_pct":"Carbon %",
        "UTS":"UTS (MPa)",
        "Elongation":"Elongation (%)"
    }).copy()
    
    show_df["Inspection Lot Date"] = show_df["Inspection Lot Date"].dt.strftime("%d-%b-%Y")
    st.dataframe(show_df.round(4), use_container_width=True, height=320)

st.markdown("---")
st.markdown(f"<center style='color:{FOOTER_CLR};font-size:13px; font-weight:500; margin-top:20px'>Maruti Suzuki · IoT SPACE Quality Dashboard · Press Shop</center>",
            unsafe_allow_html=True)