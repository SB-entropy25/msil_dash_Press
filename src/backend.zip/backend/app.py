from fastapi import FastAPI
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from services.data_loader import load_data
from services.filtering import apply_filters
from services.analytics import calculate_kpis
from services.alerts import (
    get_alert_summary,
    get_oos_records,
    get_warning_records,
)
from services.monitor import (
    get_daily_monitor,
    get_supplier_intake,
    get_materials_processed,
)
from services.charts import (
    get_chart
)
app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://127.0.0.1:3000",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
master_df = load_data()


from typing import List, Optional

from typing import List, Optional


class DashboardRequest(BaseModel):
    materials: List[str] = []
    suppliers: List[str] = []
    start_date: Optional[str] = None
    end_date: Optional[str] = None

class ChartRequest(
    DashboardRequest
):
    chart_name: str

@app.post("/charts")
def charts(
    payload: ChartRequest
):

    filtered = apply_filters(
        master_df,
        payload.materials,
        payload.suppliers,
        payload.start_date,
        payload.end_date,
    )

    return {

        "chart":
        get_chart(
            payload.chart_name,
            filtered
        )
    }
@app.post("/daily-monitor")
def daily_monitor(
    payload: DashboardRequest
):

    filtered = apply_filters(
        master_df,
        payload.materials,
        payload.suppliers,
        payload.start_date,
        payload.end_date,
    )

    return {

        "summary":
        get_daily_monitor(filtered),

        "supplier_intake":
        get_supplier_intake(filtered),

        "materials_processed":
        get_materials_processed(filtered)
    }
@app.post("/alerts")
def alerts(payload: DashboardRequest):

    filtered = apply_filters(
        master_df,
        payload.materials,
        payload.suppliers,
        payload.start_date,
        payload.end_date,
    )

    return {
        "summary":
        get_alert_summary(filtered),

        "critical":
        get_oos_records(filtered),

        "warnings":
        get_warning_records(filtered),
    }
    
@app.get("/")
def home():
    return {
        "message": "Material Inspection Backend Running"
    }


@app.get("/filters")
def filters():

    return {
        "materials": sorted(
            master_df["Material Number"]
            .dropna()
            .unique()
            .tolist()
        ),

        "suppliers": sorted(
            master_df["Supplier Name"]
            .dropna()
            .unique()
            .tolist()
        ),
    }


@app.post("/dashboard")
def dashboard(payload: DashboardRequest):

    filtered = apply_filters(
        master_df,
        payload.materials,
        payload.suppliers,
        payload.start_date,
        payload.end_date,
    )

    return calculate_kpis(filtered)